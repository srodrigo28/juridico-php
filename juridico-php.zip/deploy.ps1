# Parâmetros
$usuarioSSH = "srodrigo"
$servidor = "77.37.126.7"
$portaSSH = 22
$caminhoLocal = "C:\xampp\htdocs\www\v2\juridico-php\*"
$caminhoRemoto = "/var/www/adv.precifex.com/"
$usuarioMySQL = "srodrigo"
$senhaMySQL = "@dV#sRnAt98!"
$banco = "adv"

Write-Host "Subindo arquivos via SCP..."
scp -P $portaSSH -r $caminhoLocal "$usuarioSSH@$servidor:$caminhoRemoto"

Write-Host "Criando banco de dados se não existir..."
$mysqlCmd = "mysql -u$usuarioMySQL -p'$senhaMySQL' -e `"CREATE DATABASE IF NOT EXISTS $banco CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`""
$sshCmd = "ssh -p $portaSSH $usuarioSSH@$servidor $mysqlCmd"
Invoke-Expression $sshCmd

Write-Host "Deploy finalizado."