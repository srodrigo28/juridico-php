> ## Acesso externo

```
$DB_CONFIG = [
    'host' => '77.37.126.7',
    'port' => 3306,
    'database' => 'juridico',
    'username' => '',
    'password' => '',
    'charset' => 'utf8mb4'
];
```


> ## Acesso Interno
```
$DB_CONFIG = [
    'host' => 'localhost',
    'port' => 3306,
    'database' => 'juridico',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4'
];
```